document.getElementById('botao').addEventListener('click', function() {
    const num = parseInt(document.getElementById('numero').value);
    if (isNaN(num)) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um número válido.';
        return;
    }
    let result = '<h4>Tabuada do ' + num + ':</h4>';
    for (let i = 0; i <= 10; i++) {
        result += `${num} x ${i} = ${num * i}<br>`;
    }
    document.getElementById('resultado').innerHTML = result;
});