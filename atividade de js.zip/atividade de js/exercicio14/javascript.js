document.getElementById('botao').addEventListener('click', function() {
    const valor = parseFloat(document.getElementById('valor').value);
    if (isNaN(valor) || valor < 0) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um valor válido.';
        return;
    }
    let desconto = 0;
    if (valor > 500) {
        desconto = 0.2;
    } else if (valor > 100) {
        desconto = 0.1;
    }
    const valorFinal = valor * (1 - desconto);
    document.getElementById('resultado').innerHTML = `Valor original: R$ ${valor.toFixed(2)}<br>Desconto: ${(desconto * 100)}%<br>Valor final: R$ ${valorFinal.toFixed(2)}`;
});