let segundos = 0;
let intervalo = null;

function atualizarTempo() {
    const horas = Math.floor(segundos / 3600);
    const minutos = Math.floor((segundos % 3600) / 60);
    const segs = segundos % 60;
    document.getElementById('tempo').innerHTML = 
        `${horas.toString().padStart(2, '0')}:${minutos.toString().padStart(2, '0')}:${segs.toString().padStart(2, '0')}`;
}

document.getElementById('iniciar').addEventListener('click', function() {
    if (intervalo === null) {
        intervalo = setInterval(() => {
            segundos++;
            atualizarTempo();
        }, 1000);
    }
});

document.getElementById('pausar').addEventListener('click', function() {
    clearInterval(intervalo);
    intervalo = null;
});

document.getElementById('reiniciar').addEventListener('click', function() {
    clearInterval(intervalo);
    intervalo = null;
    segundos = 0;
    atualizarTempo();
});