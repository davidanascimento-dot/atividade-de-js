document.getElementById('botao').addEventListener('click', function() {
    const idade = parseInt(document.getElementById('idade').value);
    if (isNaN(idade) || idade < 0) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite uma idade válida.';
        return;
    }
    let categoria;
    if (idade < 12) {
        categoria = 'Criança';
    } else if (idade < 18) {
        categoria = 'Adolescente';
    } else if (idade < 65) {
        categoria = 'Adulto';
    } else {
        categoria = 'Idoso';
    }
    if (idade > 99){
        categoria = 'morto';
    }
    
    document.getElementById('resultado').innerHTML = `Você é: ${categoria}`;
});