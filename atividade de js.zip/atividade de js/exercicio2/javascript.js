document.getElementById('botao').addEventListener('click', function() {
    const num = parseInt(document.getElementById('numero').value);
    const operacao = document.querySelector('input[name="operacao"]:checked').value;
    if (isNaN(num)) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um número válido.';
        return;
    }
    let result = '<h4>Resultado:</h4>';
    for (let i = 0; i <= 10; i++) {
        let calc;
        switch (operacao) {
            case 'soma':
                calc = num + i;
                result += `${num} + ${i} = ${calc}<br>`;
                break;
            case 'subtracao':
                calc = num - i;
                result += `${num} - ${i} = ${calc}<br>`;
                break;
            case 'divisao':
                calc = i !== 0 ? (num / i).toFixed(2) : 'Indefinido';
                result += `${num} / ${i} = ${calc}<br>`;
                break;
            case 'multiplicacao':
                calc = num * i;
                result += `${num} x ${i} = ${calc}<br>`;
                break;
        }
    }
    document.getElementById('resultado').innerHTML = result;
});