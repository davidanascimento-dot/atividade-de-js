document.getElementById('botao').addEventListener('click', function() {
    const texto = document.getElementById('texto').value;
    const chars = texto.length;
    const words = texto.trim().split(/\s+/).filter(word => word.length > 0).length;
    let uppercase = 0;
    for (let char of texto) {
        if (char >= 'A' && char <= 'Z') {
            uppercase++;
        }
    }
    document.getElementById('resultado').innerHTML = `Caracteres: ${chars}<br>Palavras: ${words}<br>Letras maiúsculas: ${uppercase}`;
});