function calcular(operacao) {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    if (isNaN(num1) || isNaN(num2)) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite números válidos.';
        return;
    }
    let result;
    switch (operacao) {
        case 'soma':
            result = num1 + num2;
            break;
        case 'subtrair':
            result = num1 - num2;
            break;
        case 'multiplicar':
            result = num1 * num2;
            break;
        case 'dividir':
            if (num2 === 0) {
                result = 'Divisão por zero';
            } else {
                result = num1 / num2;
            }
            break;
    }
    document.getElementById('resultado').innerHTML = `Resultado: ${result}`;
}

document.getElementById('soma').addEventListener('click', () => calcular('soma'));
document.getElementById('subtrair').addEventListener('click', () => calcular('subtrair'));
document.getElementById('multiplicar').addEventListener('click', () => calcular('multiplicar'));
document.getElementById('dividir').addEventListener('click', () => calcular('dividir'));