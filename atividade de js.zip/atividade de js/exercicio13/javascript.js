document.getElementById('botao').addEventListener('click', function() {
    const nome = document.getElementById('nome').value;
    const idade = document.getElementById('idade').value;
    const email = document.getElementById('email').value;
    if (!nome || !idade || !email) {
        document.getElementById('resultado').innerHTML = 'Por favor, preencha todos os campos.';
        return;
    }
    document.getElementById('resultado').innerHTML = `Nome: ${nome}<br>Idade: ${idade}<br>E-mail: ${email}`;
});