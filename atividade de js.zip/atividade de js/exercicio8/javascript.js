document.getElementById('botao').addEventListener('click', function() {
    const reais = parseFloat(document.getElementById('reais').value);
    const cotacao = parseFloat(document.getElementById('cotacao').value);
    if (isNaN(reais) || isNaN(cotacao) || cotacao <= 0) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite valores válidos.';
        return;
    }
    const dolares = reais / cotacao;
    document.getElementById('resultado').innerHTML = `R$ ${reais} equivale a US$ ${dolares.toFixed(2)}.`;
});