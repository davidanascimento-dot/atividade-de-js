const numeroSecreto = Math.floor(Math.random() * 100) + 1;

document.getElementById('botao').addEventListener('click', function() {
    const palpite = parseInt(document.getElementById('palpite').value);
    if (isNaN(palpite) || palpite < 1 || palpite > 100) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um número entre 1 e 100.';
        return;
    }
    if (palpite === numeroSecreto) {
        document.getElementById('resultado').innerHTML = 'Parabéns! Você acertou!';
    } else if (palpite < numeroSecreto) {
        document.getElementById('resultado').innerHTML = 'Muito baixo! Tente novamente.';
    } else {
        document.getElementById('resultado').innerHTML = 'Muito alto! Tente novamente.';
    }
});