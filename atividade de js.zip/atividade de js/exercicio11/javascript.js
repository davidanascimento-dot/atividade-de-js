document.getElementById('botao').addEventListener('click', function() {
    let num = parseInt(document.getElementById('numero').value);
    if (isNaN(num) || num < 0) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um número válido.';
        return;
    }
    const interval = setInterval(() => {
        document.getElementById('resultado').innerHTML = num;
        num--;
        if (num < 0) {
            clearInterval(interval);
            document.getElementById('resultado').innerHTML = 'Fim!';
        }
    }, 1000);
});