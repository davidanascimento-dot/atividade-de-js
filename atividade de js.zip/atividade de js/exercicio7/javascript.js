document.getElementById('botao').addEventListener('click', function() {
    const num = parseInt(document.getElementById('numero').value);
    if (isNaN(num)) {
        document.getElementById('resultado').innerHTML = 'Por favor, digite um número válido.';
        return;
    }
    const tipo = num % 2 === 0 ? 'Par' : 'Ímpar';
    document.getElementById('resultado').innerHTML = `O número ${num} é ${tipo}.`;
});